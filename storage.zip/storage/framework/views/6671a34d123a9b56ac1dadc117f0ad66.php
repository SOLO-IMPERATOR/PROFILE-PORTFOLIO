<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['able','delay', 'active' => false]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['able','delay', 'active' => false]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>
<div class="skill-card" data-category="<?php echo e($able->category->name); ?>" data-aos="zoom-in" data-aos-delay="<?php echo e($delay); ?>">
    <div class="skill-icon-wrap">
        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($able->class_icon): ?>
            <i class="<?php echo e($able->class_icon); ?> colored"></i>
        <?php elseif($able->svg): ?>
            <?php echo $able->svg; ?>

        <?php else: ?>
            <img src="<?php echo e(Storage::url($able->image)); ?>" alt="<?php echo e($able->name); ?>">
        <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        
    </div>
    <h4><?php echo e($able->name); ?></h4>
    <div class="skill-bar"><div class="skill-progress" data-width="<?php echo e($able->level); ?>"></div></div>
    <span class="skill-level"><?php echo e($able->level); ?>%</span>
</div>
<?php /**PATH /var/www/serveportfolio/PROFILE-PORTFOLIO/resources/views/components/ables/able.blade.php ENDPATH**/ ?>