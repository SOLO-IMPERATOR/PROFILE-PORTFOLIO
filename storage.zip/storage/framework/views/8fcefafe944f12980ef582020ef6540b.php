<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['categories', 'projects']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['categories', 'projects']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<!-- ======================== PORTFOLIO SECTION ======================== -->
<section id="portfolio" class="section portfolio">
    <div class="container">
        <div class="section-header" data-aos="fade-up">
            <span class="section-tag"><?php echo e(__("Mои работы")); ?></span>
            <h2 class="section-title"><?php echo e(__("Проекты")); ?></h2>
            <div class="section-line"></div>
        </div>
        <div class="portfolio-filters" data-aos="fade-up" data-aos-delay="100">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button class="filter-btn" data-filter="<?php echo e(\Illuminate\Support\Str::slug($category->name)); ?>">
                    <?php echo e($category->name); ?>

                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
        <div class="portfolio-grid" id="portfolioGrid">
            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $projects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $project): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php
                    $cats = $project->category->map(fn($c) => \Illuminate\Support\Str::slug($c->name))->implode(' ');
                    $gallery = $project->gallery ?? [];
                    $galleryJson = json_encode(
                        collect($gallery)->map(fn($img) => [
                            'href'  => \Illuminate\Support\Facades\Storage::url($img),
                            'type'  => 'image',
                            'title' => $project->name,
                        ])->values()->all()
                    );
                ?>
                <div class="project-card" data-category="<?php echo e($cats); ?>" data-aos="fade-up" data-aos-delay="<?php echo e($i * 100); ?>">
                    <div class="project-image">
                      
                        <div class="project-image-bg" style="background: <?php echo e($project->background ?? 'linear-gradient(135deg, #6366f1, #06b6d4)'); ?>">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->class_icon): ?>
                                <i class="<?php echo e($project->class_icon); ?>"></i>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                       
                        <div class="project-overlay">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($project->url): ?>
                                <a href="<?php echo e($project->url); ?>" target="_blank" rel="noopener" class="project-overlay-btn">
                                    <i class="fas fa-external-link-alt"></i>
                                    <span><?php echo e(__("Посетить сайт")); ?></span>
                                </a>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if(!empty($gallery)): ?>
                                <button type="button" class="project-overlay-btn gallery-btn"
                                        data-gallery='<?php echo e($galleryJson); ?>'>
                                    <i class="fas fa-images"></i>
                                    <span><?php echo e(__("Галерея")); ?></span>
                                </button>
                            <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                    <div class="project-info">
                        <h3><?php echo e($project->name); ?></h3>
                        <p><?php echo $project->description; ?></p>
                        <div class="project-tags">
                            <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $project->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <span class="project-tag"><?php echo e($tag->name); ?></span>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
        </div>
    </div>
</section>
<?php /**PATH /var/www/serveportfolio/PROFILE-PORTFOLIO/resources/views/components/projects/section.blade.php ENDPATH**/ ?>