  <?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['categories']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['categories']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

  <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($categories): ?>
  <!-- ======================== SKILLS SECTION ======================== -->
    <section id="skills" class="section skills">
        <div class="container">
            <div class="section-header" data-aos="fade-up">
                <span class="section-tag" data-i18n="skills.tag">What I work with</span>
                <h2 class="section-title" data-i18n="skills.title">Skills & Technologies</h2>
                <div class="section-line"></div>
            </div>

            <!-- Skills Category Tabs -->
            <div class="skills-tabs" data-aos="fade-up" data-aos-delay="100">
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button
                    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                        'skill-tab',
                        'active' => $loop->first
                    ]); ?>"
                    data-category="<?php echo e($category->name); ?>">
                        <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php if($category->class_icon): ?>
                            <i class="<?php echo e($category->class_icon); ?>"></i>
                        <?php elseif($category->svg): ?>
                            <?php echo $category->svg; ?>

                        <?php else: ?>
                            <img src="<?php echo e($category->image); ?>" alt="<?php echo e($category->name); ?>"
                        <?php endif; ?>
                        <span><?php echo e($category->name); ?></span>
                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>

            <!-- Skills Grid -->
            <?php $delay = 100; ?>
            <div class="skills-grid" id="skillsGrid">
                <!-- Backend -->
                <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if BLOCK]><![endif]--><?php endif; ?><?php $__currentLoopData = $category->abillities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $able): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php if (isset($component)) { $__componentOriginal5d1ab9db3e00f7c8ed3c8d41e55ca07c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal5d1ab9db3e00f7c8ed3c8d41e55ca07c = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ables.able','data' => ['able' => $able,'delay' => $delay,'active' => (bool)$loop->parent->first]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ables.able'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['able' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($able),'delay' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($delay),'active' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute((bool)$loop->parent->first)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal5d1ab9db3e00f7c8ed3c8d41e55ca07c)): ?>
<?php $attributes = $__attributesOriginal5d1ab9db3e00f7c8ed3c8d41e55ca07c; ?>
<?php unset($__attributesOriginal5d1ab9db3e00f7c8ed3c8d41e55ca07c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal5d1ab9db3e00f7c8ed3c8d41e55ca07c)): ?>
<?php $component = $__componentOriginal5d1ab9db3e00f7c8ed3c8d41e55ca07c; ?>
<?php unset($__componentOriginal5d1ab9db3e00f7c8ed3c8d41e55ca07c); ?>
<?php endif; ?>
                    <?php $delay += 50 ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
            </div>
        </div>
    </section>
    <?php endif; ?><?php if(\Livewire\Mechanisms\ExtendBlade\ExtendBlade::isRenderingLivewireComponent()): ?><!--[if ENDBLOCK]><![endif]--><?php endif; ?>
<?php /**PATH /var/www/serveportfolio/PROFILE-PORTFOLIO/resources/views/components/ables/section.blade.php ENDPATH**/ ?>